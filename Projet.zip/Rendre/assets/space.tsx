<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="space" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="space.png" width="128" height="128"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.126546" y="0" width="31.8263" height="31.9528"/>
  </objectgroup>
 </tile>
 <tile id="1">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0632729" y="0.126546" width="31.9528" height="31.9528"/>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0632729" y="0.0632729" width="31.8263" height="31.8263"/>
  </objectgroup>
 </tile>
 <tile id="3">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.126546" y="0" width="31.9528" height="32.0794"/>
  </objectgroup>
 </tile>
 <tile id="8">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32.0161" height="32.1427"/>
  </objectgroup>
 </tile>
 <tile id="9">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.126546" y="-0.0632729" width="31.8896" height="32.0794"/>
  </objectgroup>
 </tile>
 <tile id="10">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0632729" y="0.0632729" width="31.8896" height="31.8896"/>
  </objectgroup>
 </tile>
 <tile id="11">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.126546" y="0" width="31.763" height="31.8896"/>
  </objectgroup>
 </tile>
 <tile id="12">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.126546" y="-0.0632729" width="31.8263" height="32.0794"/>
  </objectgroup>
 </tile>
</tileset>

package com.project.spaceship;

import java.util.List;

import com.badlogic.gdx.maps.tiled.TiledMap;

abstract public class Behaviour { //define the behaviour of the enemies
	private Enemy e;
	public Behaviour(Enemy e) {
		this.e=e;
	}
	
	public abstract void attackTarget();//define how the character attacks
	
	public abstract Pair movement(List<Pair>l);	//define how the character moves
	
	public abstract void act(Combat c,TiledMap m);//define how the character acts
	
	public Char getChar() {
		return this.e;
	}
	
	public void setChar(Char c) {
		this.e=(Enemy)c;
	}
	
}

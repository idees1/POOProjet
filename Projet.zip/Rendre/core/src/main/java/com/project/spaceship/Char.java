package com.project.spaceship;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;

public abstract class Char { //base class of every characters
	
	private Texture charTexture;
	private Sprite charSprite;
	private int hp=1; //number of the character's health point
	private int init=1; //determine the character's initiative
	private int mp=1;	//movement point
	private int ap=1;	//range 
	private int dam=1;	//number of damage dice
	private int maxHp;
	private int maxDam;
	private int maxMp;
	
	public Char(String p) {
		this.charTexture= new Texture(p);
		this.charSprite= new Sprite(this.charTexture);
		this.charSprite.setSize(1,1);
	}
	
	public Char(String p,int h, int i,int m, int a, int d) {
		this.charTexture= new Texture(p);
		this.charSprite= new Sprite(this.charTexture);
		this.charSprite.setSize(1,1);
		this.hp=h;
		this.init=i;
		this.mp=m;
		this.ap=a;
		this.dam=d;
		this.maxHp=h;
		this.maxMp=m;
		this.maxDam=d;
	}
	
	public abstract void attack(Char c);
	
	public void hurt(int h) {	//character take damage
		this.hp=this.hp-h;
	}
	
	public void heal(int h) {	//character heal damage
		this.hp=this.maxHp>=this.hp+h ?this.hp+h :this.maxHp ;
		
	}

	public void debuff(int d) {		//character is debuff
		this.mp=this.mp-d;
		this.dam=this.dam-d;
		if(this.mp<1) {
			this.mp=1;
			hurt((int)Math.floor(d/2));
		}
		if(this.dam<1) {
			this.dam=1;
			hurt((int)Math.floor(d/2));
		}
	}
	
	public void buff(int d) {		//character is buff
		this.mp=this.mp+d;
		this.dam=this.dam+d;
		if(this.mp>6) {
			this.mp= this.maxMp<6 ? 6 : this.maxMp;
			heal((int)Math.floor(d/2));
		}
		if(this.dam>10) {
			this.dam= this.maxDam<8 ? 8 : this.maxDam;
			heal((int)Math.floor(d/2));
		}
	}
	
	public Sprite getSprite() {
		return this.charSprite;
	}
	
	public int getHp() {
		return this.hp;
	}
	
	public int getMaxHp() {
		return this.maxHp;
	}
	
	public int getInit() {
		return this.init;
	}
	
	public int getMp() {
		return this.mp;
	}
	
	public int getAp() {
		return this.ap;
	}
	
	public int getDam() {
		return this.dam;
	}
	
	public int getMaxMp() {
		return this.maxMp;
	}
	
	public int getMaxDam() {
		return this.maxDam;
	}
	
	public boolean isBuff() {
		return this.mp>this.maxMp||this.dam>this.maxDam;
	}
	
	public boolean isDebuff() {
		return this.mp<this.maxMp||this.dam<this.maxDam;
	}
	
	public void setSprite(String s) {
		this.charSprite=new Sprite(new Texture(s));
	}
	
	public void setHp(int h) {
		this.hp=h;
	}
	
	public void setMaxHp(int h) {
		this.maxHp=h;
	}
	
	public void setInit(int i) {
		this.init=i;
	}
	public void setMp(int h) {
		this.mp=h;
	}
	
	public void setAp(int i) {
		this.ap=i;
	}
	public void setDam(int h) {
		this.dam=h;
	}
	
	public void setMaxMp(int i) {
		this.maxMp=i;
	}
	public void setMaxDam(int h) {
		this.maxDam=h;
	}
	
	
}

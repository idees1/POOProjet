package com.project.spaceship;

public class Support extends Player{

	public Support(String p) {
		super(p);
	}
	
	public Support(String p,int h, int i,int m,int a, int d,int l) {
		super(p,h,i,m,a,d,l);
	}

	public void attack(Char c) {
		if(c instanceof Enemy) {
			c.debuff(this.getDam());
		}else {
			c.buff(this.getDam());
			c.heal(this.getDam());
		}
	}
}

package com.project.spaceship;

import java.util.List;

import com.badlogic.gdx.maps.tiled.TiledMap;

public class Ranged extends Behaviour{
	
	private List<Pair>mov;
	private List<Pair>tar;
	private List<Char> players;
	private Combat combat;
	private Pair coor;

	public Ranged(Enemy e) {
		super(e);
	}

	@Override
	public void act(Combat c,TiledMap m) {
		combat=c;
		mov=combat.curMov(this.getChar(),m);
		tar=combat.curTarget(this.getChar());
		coor=combat.getPair(this.getChar());
		players=combat.getPlayerList();
		if(tar.isEmpty()) {//if no target in range: move
			coor=movement(mov);
			this.getChar().getSprite().setX(coor.getX());
			this.getChar().getSprite().setY(coor.getY());
			tar=combat.curTarget(this.getChar());
		}
		attackTarget();

		
	}
	@Override
	public Pair movement(List<Pair> l) {//move the tile in range of a player which is the farthest of the closest of them
		Pair close=coor;
		Pair res=coor;
		int sum=18;
		
		for(Char i:players) {//get the closest player
			Pair p=combat.getPair(i);
			int s=Math.abs(coor.getX()-p.getX())+Math.abs(coor.getY()-p.getY());
			if(s<sum) {
				sum=s;
				close=p;
			}
		}
		sum=18;
		for(Pair p:mov) {
			int s=Math.abs(close.getX()-p.getX())+Math.abs(close.getY()-p.getY());
			if(s<sum) {
				sum=s;
				res=p;
			}
			if(s==this.getChar().getAp()) {
				res=p;
				break;
			}
		}
		return res;
	}

	@Override
	public void attackTarget() { //attack closest player
		if(tar.isEmpty()==false) {//if still no target in range: end turn
			Char c=combat.getChar(tar.get(0));
			this.getChar().attack(c);
    		if(c.getHp()<=0) {
    			combat.removeChar(c);
    		}
		}
		
	}



}

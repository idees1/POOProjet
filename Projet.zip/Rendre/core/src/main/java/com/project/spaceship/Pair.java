package com.project.spaceship;

public class Pair implements Comparable<Pair>{
	private int x;
	private int y;
	public Pair(int x,int y) {
		this.x=x;
		this.y=y;	
	}
	
	@Override
	public int compareTo(Pair p) {
		if(this.x==p.getX()&&this.y==p.getY()) {
			return 1;
		}
		return 0;
	}
	
	public String toString() {
		return this.x+" "+this.getY();
	}
	
	public int getX() {
		return this.x;
	}
	
	public void setX(int x) {
		this.x=x;
	}
	
	public int getY() {
		return this.y;
	}
	
	public void setY(int x) {
		this.y=x;
	}
}
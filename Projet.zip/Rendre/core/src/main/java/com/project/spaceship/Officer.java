package com.project.spaceship;

import java.util.List;

import com.badlogic.gdx.maps.tiled.TiledMap;

public class Officer extends Behaviour{

	private List<Pair>mov;
	private List<Pair>tar;
	private List<Char> players;
	private List<Char> allies;
	private Combat combat;
	private Pair coor;

	
	public Officer(Enemy e) {
		super(e);
	}

	@Override
	public void attackTarget() {//same as ranged
		if(tar.isEmpty()==false) {
			Char c=combat.getChar(tar.get(0));
			this.getChar().attack(c);
    		if(c.getHp()<=0) {
    			combat.removeChar(c);
    		}
		}
		for(Char c:allies) {//buff every allies including self at less than three tiles of the officer
			Pair p=combat.getPair(c);
			if(Math.abs(coor.getX()-p.getX())+Math.abs(coor.getY()-p.getY())<3) {
				c.buff(1);
			}
		}
	}

	@Override
	public Pair movement(List<Pair> l) {//same as ranged
		Pair close=coor;
		Pair res=coor;
		int sum=18;
		
		for(Char i:players) {
			Pair p=combat.getPair(i);
			int s=Math.abs(coor.getX()-p.getX())+Math.abs(coor.getY()-p.getY());
			if(s<sum) {
				sum=s;
				close=p;
			}
		}
		sum=18;
		for(Pair p:mov) {
			int s=Math.abs(close.getX()-p.getX())+Math.abs(close.getY()-p.getY());
			if(s<sum) {
				sum=s;
				res=p;
			}
			if(s==this.getChar().getAp()) {
				res=p;
				break;
			}
		}
		return res;
	}

	@Override
	public void act(Combat c, TiledMap m) {//same as ranged
		combat=c;
		mov=combat.curMov(this.getChar(),m);
		tar=combat.curTarget(this.getChar());
		allies=combat.getEnemyList();
		coor=combat.getPair(this.getChar());
		players=combat.getPlayerList();
		if(tar.isEmpty()) {
			coor=movement(mov);
			this.getChar().getSprite().setX(coor.getX());
			this.getChar().getSprite().setY(coor.getY());
			tar=combat.curTarget(this.getChar());
		}
		attackTarget();
	}

}

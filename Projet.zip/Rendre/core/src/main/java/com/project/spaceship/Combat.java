package com.project.spaceship;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;

public class Combat {
	private List<Char> charList;
	private List<Char> enList;
	private List<Char> playList;
	
	public Combat(String s) {
		this.charList=new LinkedList<>(); //list of all characters
		this.playList=new LinkedList<>(); //list of players
		this.enList=new Parser(s).parse();//list of enemies
		this.charList.addAll(enList);
	}
	
	
	public Char getFirst() {//get the next character to act
		Char c= charList.get(0);
		charList.remove(0);
		charList.add(c);
		return c;
	}
	
	public boolean finished() {	//check if the combat is finished
		if(charList.get(0) instanceof Player) {
			for(Char i:charList) {
				if(i instanceof Enemy) {
					return false;
				}
			}
		}else {
			for(Char i:charList) {
				if(i instanceof Player) {
					return false;
				}
			}
		}
		return true;
	}
	
	public void enmyTurn(Char c,TiledMap m) {	//manage enemy turn
		Enemy e=(Enemy)c;
		Behaviour b=e.getType();
		b.act(this,m);

		
	}
	public void addChar(Char c) { //add player characters
		charList.add(c);
		playList.add(c);
	}
	
	public void removeChar(Char c) {
		charList.remove(c);
		if(c instanceof Enemy) {
			enList.remove(c);
		}else {
			playList.remove(c);
		}
	}
	
	public void sortCharList() {//sort the character list by initiative
		charList.sort(new Comparator<Char>() {
            public int compare(Char c1,Char c2) {
                if (c1.getInit() < c2.getInit()) return 1;
                if (c1.getInit() > c2.getInit()) return -1;
                return 0;
            }
        });
		
	}
	
	public List<Pair> getPairList(){
		List<Pair> pl=new ArrayList<>();
		for(Char i:charList) {
			pl.add(new Pair((int)Math.floor(i.getSprite().getX()),(int)Math.floor(i.getSprite().getY())));
		}
		return pl;
	}
	
	public List<Char> getCharList(){
		return charList;
	}
	
	public List<Char> getPlayerList(){
		return playList;
	}
	
	public List<Char> getEnemyList(){
		return enList;
	}
	
	public Char getChar(Pair p) {//get a character from a pair
		Char res=null;
		for(Char i:charList) {
			if(new Pair((int)Math.floor(i.getSprite().getX()),(int)Math.floor(i.getSprite().getY())).compareTo(p)==1) {
				res=i;
			}
		}
		return res;
	}
	
	public Pair getPair(Char p) {//get a pair from a character
		return new Pair((int)Math.floor(p.getSprite().getX()),(int)Math.floor(p.getSprite().getY()));
	}
	
	public boolean emptyTile(Pair p) {  //check if a tile is empty
		for(Char i:charList) {
			if(this.getPair(i).compareTo(p)==1) {
				return false;
			}
		}
		return true;
	}
	
	
	public List<Pair> curTarget(Char c){ //calculate current character possible target
		List<Char> cTar=new ArrayList<>();
		List<Pair>tar=new LinkedList<>();
    	Pair p=this.getPair(c);
		if(c instanceof Player) {
			if((Player)c instanceof Support) {
				cTar.addAll(charList);
				cTar.remove(c);
			}else {
				cTar.addAll(enList);
			}
		}else {
			cTar.addAll(playList);
		}		
		for(Char i:cTar) {
			Pair p1=this.getPair(i);
			int x=Math.abs(p.getX()-p1.getX());
			int y=+Math.abs(p.getY()-p1.getY());
			if(x+y<c.getAp()+1||(x==1&&y==1)) {
				tar.add(p1);
			}
		}
		return tar;
	}
	
	public List<Pair> curMov(Char current, TiledMap map) { //calculate current character possible movement
    	List<Pair> m=new ArrayList<>();
    	List<Pair>cPair=getPairList();
    	List<Pair> mov=new LinkedList<>();
    	Queue<Pair> movQueue=new LinkedList<>();
    	List<Pair> backList=new ArrayList<>();
    	int x=(int)Math.floor(current.getSprite().getX());
    	int y=(int)Math.floor(current.getSprite().getY());
    	movQueue.add(new Pair(x,y));
    	while(movQueue.isEmpty()==false) { //possible movement
    			Pair k=movQueue.poll();
        		Pair p1=new Pair(k.getX()+1,k.getY());
        		Pair p2=new Pair(k.getX()-1,k.getY());
        		Pair p3=new Pair(k.getX(),k.getY()+1);
        		Pair p4=new Pair(k.getX(),k.getY()-1);
        		Pair p5=new Pair(k.getX()+1,k.getY()+1);
        		Pair p6=new Pair(k.getX()-1,k.getY()-1);
        		Pair p7=new Pair(k.getX()+1,k.getY()-1);
        		Pair p8=new Pair(k.getX()-1,k.getY()+1);
        		List<Pair> pList=new ArrayList<>();
        		pList.add(p1);
        		pList.add(p2);
        		pList.add(p3);
        		pList.add(p4);
        		pList.add(p5);
        		pList.add(p6);
        		pList.add(p7);
        		pList.add(p8);
        		for(Pair p:pList) {
        			boolean contain=true;
        			for(Pair c:backList) {
        				if(c.compareTo(p)==1){
        					contain=false;
        				}
        			}
        			if(contain&&(Math.abs(x-p.getX())+Math.abs(y-p.getY()))<current.getMp()+1) {
        				movQueue.add(p);
        				backList.add(p);
        				m.add(p);
        			}
        		}
    	}
    	mov.addAll(m);
        for(MapObject o:map.getLayers().get("Wall").getObjects()) { //add wall tiles
        	if(o instanceof RectangleMapObject) {
        		
        		int cosX=(int)((float) o.getProperties().get("x")/32);
        		int cosY=(int)((float) o.getProperties().get("y")/32);
        		int width=(int)((float) o.getProperties().get("width")/32);
        		int height=(int)((float) o.getProperties().get("height")/32);
        		for(int u=cosX;u<width+cosX;u++) {
            		for(int h=cosY;h<height+cosY;h++) {
            			cPair.add(new Pair(u,h));
            		}

        		}
        		
        		
        	}
        }
     	
    	for(Pair u:cPair) { //add screen borders
    		for(Pair i:m) {
    			if(i.compareTo(u)==1||i.getX()>9||i.getX()<0||i.getY()>9||i.getY()<0) {
    				if(mov.contains(i)) {
    					mov.remove(i);
    				}
    			}
    		}
    	}
    	
    	return mov;
    }
	
}

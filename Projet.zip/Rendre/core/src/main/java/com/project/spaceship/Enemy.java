package com.project.spaceship;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Enemy extends Char{
	
	private Behaviour type;
	public Enemy(String p) {
		super(p);
	}
	
	public Enemy(String p,int h, int i,int m, int a, int d, String t){
		super(p,h,i,m,a,d);
		try {
			Class<?> cl= Class.forName("com.project.spaceship."+t);	//define enemy behaviour
			Constructor<?> cons = cl.getConstructor(Enemy.class);
			this.type=(Behaviour) cons.newInstance(this);
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			e.printStackTrace();
		}
	}
	
	public Behaviour getType() {
		return this.type;
	}
	
	public void setType(Behaviour l) {
		this.type=l;
	}

	@Override
	public void attack(Char c) {
		c.hurt(this.getDam());
	}
}

package com.project.spaceship;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Parser {
	private Map<String,Map<String,String>> dic;
	private FileReader file;
	private BufferedReader br;
	private String l;
	private List<String> text;
	private List<Char> charList;
	private Map<Char,Pair> pairDic;
	private Iterator<String> it;
	
	public Parser(String s){		//parse .json combat file
		try {
			this.file=new FileReader(s);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		this.br=new BufferedReader(file);
		this.text=new ArrayList<>();
		this.pairDic=new HashMap<>();
		this.dic=new HashMap<>();
		this.charList=new ArrayList<>();
		try {
			while((l=br.readLine())!=null){
			    text.add(l);
			}
		this.file.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Map<Char,Pair> getDic(){ //get a director of the players and their coordinates
		return this.pairDic;
	}
	
	public List<Char> parse() { //start the parsing
		it=text.iterator();
		while(it.hasNext()) {
			String line =it.next().replace(" ", "").replace("\"","").replace(",","").replace("\t","");
			if(line.contains(":{")) {
				setType(line);
			}
			if(line.contains("Enemy:[")) {
				setEnemy();
			}
			if(line.contains("Player:[")) {
				setPlayer();
			}
			
		}
		return charList;
		
	}
	
	private void setType(String l) { //define the different types of enemies
		String l2="";
		Map<String,String> di=new HashMap<>();
		while(it.hasNext()) {
			l2=it.next().replace(" ","").replace("\"","").replace(",","").replace("\t","");
			if(l2.contains("}")) {
				break;
			}
			
			di.put(l2.substring(0,l2.indexOf(":")),l2.substring((l2.indexOf(":")+1),l2.length()));
		}
		dic.put(l.substring(0,l.indexOf(":")), di);
		
		
	}
	

	
	private void setEnemy() {	//create enemy type
		String l3;
		while(it.hasNext()) {
			l3=it.next().replace(" ","").replace("\"","").replace(",","").replace("	", "").replace("\t","");
			if(l3.contains("{")) {
				addEnemy();
			}
		}
	}
	
	private void addEnemy() {	//add enemies to the characters list
		Map<String,String> type=new HashMap<>();
		String l4;
		int x=0;
		int y=0;
		while(it.hasNext()) {
			l4=it.next().replace(" ","").replace("\"","").replace(",","").replace("\t","");
			if(l4.contains("}")) {
				Enemy e;
				e = new Enemy(type.get("sprite"),Integer.parseInt(type.get("hp")),Integer.parseInt(type.get("init")),Integer.parseInt(type.get("mp")),Integer.parseInt(type.get("ap")),Integer.parseInt(type.get("dam")),type.get("type"));
				e.getSprite().setX(x);
				e.getSprite().setY(y);
				charList.add(e);
				break;
			}
			if(l4.contains("type")) {
				type=dic.get(l4.substring(l4.indexOf(":")+1,l4.length()));
			}
			if(l4.contains("cox")) {
				x=Integer.parseInt(l4.substring(l4.indexOf(":")+1,l4.length()));
			}
			if(l4.contains("coy")) {
				y=Integer.parseInt(l4.substring(l4.indexOf(":")+1,l4.length()));
			}
			
		}
	}
	
	private void setPlayer() { //create player type
		String l3;
		while(it.hasNext()) {
			l3=it.next().replace(" ","").replace("\"","").replace(",","").replace("	", "").replace("\t","");
			if(l3.contains("{")) {
				addPlayer();
			}
		}
	}
	private void addPlayer() { //add players from c0.json
		Map<String,String> type=new HashMap<>();
		String l4;
		int x=0;
		int y=0;
		while(it.hasNext()) {
			l4=it.next().replace(" ","").replace("\"","").replace(",","").replace("\t","");
			if(l4.contains("}")) {
				Player p;
				try {
					Class<?> cl= Class.forName("com.project.spaceship."+type.get("type"));//get the class corresponding to player type
					Constructor<?> cons = cl.getConstructor(String.class,int.class,int.class,int.class,int.class,int.class,int.class);
					p=(Player) cons.newInstance(type.get("sprite"),Integer.parseInt(type.get("hp")),Integer.parseInt(type.get("init")),Integer.parseInt(type.get("mp")),Integer.parseInt(type.get("ap")),Integer.parseInt(type.get("dam")),Integer.parseInt(type.get("level")));
				} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					p=new Player(type.get("sprite"));
					e.printStackTrace();
				}
				
				p.getSprite().setX(x);
				p.getSprite().setY(y);
				pairDic.put(p,new Pair(x,y));
				break;
			}
			if(l4.contains("type")) {
				type=dic.get(l4.substring(l4.indexOf(":")+1,l4.length()));
			}
			if(l4.contains("cox")) {
				x=Integer.parseInt(l4.substring(l4.indexOf(":")+1,l4.length()));
			}
			if(l4.contains("coy")) {
				y=Integer.parseInt(l4.substring(l4.indexOf(":")+1,l4.length()));
			}
			
		}
	}
}

package com.project.spaceship;


public class Player extends Char {
	
	private int level;	//character gain a level after each combat

	public Player(String p) {
		super(p);
	}
	
	public Player(String p,int h, int i,int m,int a, int d,int l) {
		super(p,h+l,i+l,m,a,d+l);
		this.level=l;
	}
	
	
	public void restore() {	//restore player characters to their max values
		this.setHp(this.getMaxHp());
		this.setMp(this.getMaxMp());
		this.setDam(this.getMaxDam());
	}
	
	public int getLevel() {
		return this.level;
	}
	
	public void addLevel() {//increase character statistics 
		this.level++;
		this.setInit(this.getInit()+1);
		this.setMaxHp(this.getMaxHp()+1);
		this.setMaxDam(this.getMaxDam()+1);
	}
	
	
	public void setLevel(int l) {
		this.setInit(this.getInit()-level+l);
		this.setMaxHp(this.getMaxHp()-level+l);
		this.setMaxDam(this.getMaxDam()-level+l);
		this.level=l;
	}

	public void attack(Char c) {
		c.hurt(this.getDam());
	}
}

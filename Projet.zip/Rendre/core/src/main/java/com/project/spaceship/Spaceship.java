package com.project.spaceship;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Spaceship implements ApplicationListener {
	
	private TiledMap map;
	private SpriteBatch spriteBatch;
	private FitViewport viewport;
	private float unitScale;
	private OrthogonalTiledMapRenderer renderer;
	private OrthographicCamera cam;
	private Vector2 touchPos;
	private Rectangle groupRec;
	private Rectangle currentRec;
	private Sprite group;
	private String curMap;
	private Combat combat;
	private Char current;
	private Texture green;
	private Texture red;
	private Texture yellow;
	private Texture blue;
	private Texture hpRed;
	private Texture hpGreen;
	private Texture buff;
	private Texture debuff;
	private Texture title;
	private Music music;
	private List<Pair> mov;
	private List<Pair> tar;
	private Map<Char,Pair> playerDic;
	private boolean fighting;
	private boolean playerTurn;
	private boolean move;
	private boolean act;
	private boolean health;
	private boolean start;
	private float x;
	private float y;
	
	
    @Override
    public void create() {
    	
    	map = new TmxMapLoader().load("space0.tmx"); //Load starting map
    	curMap="0"; //current map index
        spriteBatch = new SpriteBatch();
        cam=new OrthographicCamera();
        viewport = new FitViewport(10, 10,cam);
        unitScale=1/32f;
        touchPos=new Vector2();
        groupRec=new Rectangle();
    	group=new Sprite(new Texture("player/Group.png"));
    	group.setY(4);
    	group.setX(1);
    	group.setSize(2,2);
        playerDic=new HashMap<>();
        currentRec=new Rectangle();
        music = Gdx.audio.newMusic(Gdx.files.internal("ui/audio.wav"));
        music.setLooping(true);
        music.setVolume(.5f);
        music.play();
        green=new Texture("ui/mov.png");
        red=new Texture("ui/tar.png");
        yellow=new Texture("ui/bonus.png");
        blue=new Texture("ui/blue.png");
        hpRed=new Texture("ui/hpred.png");
        hpGreen=new Texture("ui/hpgreen.png");
        buff=new Texture("ui/buff.png");
        debuff=new Texture("ui/debuff.png");
        title=new Texture("ui/title.png");
        health=true;	
        fighting=false;	//is in combat
        playerTurn=false;
        start=false;
        move=true;	//player character can move
        act=true;	//player character can act
    }

    @Override
    public void resize(int width, int height) {
    	viewport.update(width, height, true);
    	
    }

    @Override
    public void render() {
    	if(Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
    		Gdx.app.exit();
    		System.exit(-1);
    	}
    	if(Gdx.input.isKeyJustPressed(Input.Keys.DEL)) {
    		music.stop();
    	}
    	if(start) {
        	input();
        	if(fighting==false) {
        		rule();
        	}
        	
    	}else {
            if(Gdx.input.isKeyJustPressed(Input.Keys.ENTER)) {
            	start=true;
            	title.dispose();
            	initPlayer();
            }
    	}
    	draw();
    }
    
    private void initPlayer() {	//create players characters from c0.json
    	Parser p =new Parser("combat/c0.json");
    	p.parse();
    	playerDic=p.getDic();
    	
    }
    
    private void input() {//move the group sprite
        float speed = 5f;
        float delta = Gdx.graphics.getDeltaTime();
        
        if(fighting) {
        	fightInput();
        }else{

        	if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {        //move characters right
        		x=group.getX();
        		y=group.getY();
        		group.translateX(speed * delta); 
        	}    
        	if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {  // move characters left
        		x=group.getX();
        		y=group.getY();
        		group.translateX(-speed * delta); 
        	}
        
        	if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {  // move characters down
        		x=group.getX();
        		y=group.getY();
        		group.translateY(-speed * delta); 
        	}

        	if (Gdx.input.isKeyPressed(Input.Keys.UP)) {  // move characters up
        		x=group.getX();
        		y=group.getY();
        		group.translateY(speed * delta); 
			
        	}
        }
    }
    
    private void rule() {
        group.setX(MathUtils.clamp(group.getX(), 0, 9)); //stop characters from leaving the screen
        group.setY(MathUtils.clamp(group.getY(), 0, 9));
    	
        for(MapObject i:map.getLayers().get("Wall").getObjects()) { //Check for wall collisions
        	if(i instanceof RectangleMapObject) {
        		Rectangle rec= new Rectangle();
        		rec.set((float)Math.floor((float)i.getProperties().get("x")/32),(float)Math.floor((float)i.getProperties().get("y")/32),(float)Math.floor((float)i.getProperties().get("width")/32),(float)Math.floor((float)i.getProperties().get("height")/32));
        		if(fighting) {
        			currentRec.set(current.getSprite().getX(), current.getSprite().getY(),current.getSprite().getWidth(),current.getSprite().getHeight());
            		if (currentRec.overlaps(rec)) {
            			current.getSprite().setX(x);
            			current.getSprite().setY(y);
            		}
        		}else {
        			groupRec.set(group.getX(), group.getY(),group.getWidth(),group.getHeight());
        			if (groupRec.overlaps(rec)) {
        				group.setX(x);
        				group.setY(y);
        			}
        		}
        	}
        }
        
        for(MapObject i:map.getLayers().get("Next").getObjects()) { //Check for map transitions
        	if(i instanceof RectangleMapObject) {
        		Rectangle rec= new Rectangle();
        		rec.set((float)Math.floor((float)i.getProperties().get("x")/32),(float)Math.floor((float)i.getProperties().get("y")/32),(float)Math.floor((float)i.getProperties().get("width")/32),(float)Math.floor((float)i.getProperties().get("height")/32));
        		groupRec.set(group.getX(), group.getY(),group.getWidth(),group.getHeight());
        		if (groupRec.overlaps(rec)) {
        			curMap=Integer.toString(Integer.parseInt(curMap)+1);
        			try {
        				map = new TmxMapLoader().load("space"+curMap+".tmx");
        			}catch(Exception e) {
        				curMap="0";
        				map = new TmxMapLoader().load("space"+curMap+".tmx");
        			}
                	x=1;
                	y=5;
        			group.setX(x);
        			group.setY(y);
        			draw();
        			fight();
        		}
        	}
        }
        
    }
    
    private void draw() {	//draw sprite
        ScreenUtils.clear(Color.BLACK);
        spriteBatch.setProjectionMatrix(viewport.getCamera().combined);
        spriteBatch.begin();
        if(start) {
        	
        	renderer = new OrthogonalTiledMapRenderer(map, unitScale);	
        	renderer.setView((OrthographicCamera) viewport.getCamera());
        	renderer.render();
        	if(fighting) {
        		for(Char i:combat.getCharList()) {
        			i.getSprite().draw(spriteBatch);
    			
        			if(health) {	//draw health bar and buff/debuff icon
        				Pair p=combat.getPair(i);
        				float scale=1f/(float)i.getMaxHp();
        				int j;
    				
        				for(j=0;j<i.getHp();j++) {
        					spriteBatch.draw(hpGreen,p.getX()+j*scale, p.getY()+0.9f,scale,0.1f);
        				}
        				for(int k=j;k<i.getMaxHp()-i.getHp()+j;k++) {
        					spriteBatch.draw(hpRed,p.getX()+k*scale, p.getY()+0.9f,scale,0.1f);
        				}
    				
        				if(i.isBuff()) {
        					spriteBatch.draw(buff,p.getX(), p.getY(),1,1);
        				}else if(i.isDebuff()){
        					spriteBatch.draw(debuff,p.getX(), p.getY(),1,1);
        				}
    				
        			}
        		}
        		if(playerTurn) {//draw movement and target tiles
        			Pair p1=combat.getPair(current);
        			spriteBatch.draw(blue,p1.getX(), p1.getY(),1,1);
        			if(move) {
        				for(Pair p:mov) {
        					spriteBatch.draw(green,p.getX(), p.getY(),1,1);
        				}
        			}else {
        				spriteBatch.draw(blue,p1.getX(), p1.getY(),1,1);
        			}
        			if(act) {
        				for(Pair p:tar) {
        					if(combat.getChar(p) instanceof Enemy) {
        						spriteBatch.draw(red,p.getX(), p.getY(),1,1);
        					}
        					else {
        						spriteBatch.draw(yellow,p.getX(), p.getY(),1,1);
        					}
       					}
        			}

        		}
        	}else {
        		group.draw(spriteBatch);
        	}
        }
        else {
        	spriteBatch.draw(title,0,0,10,10);
        }
        spriteBatch.end();
    }
    
    private void fight() {  //set combat parameters
    	combat=new Combat("combat/c"+curMap+".json");
    	for(Char c:playerDic.keySet()) {
    		combat.addChar(c);
    	}
    	combat.sortCharList();
    	fighting=true;
    	newTurn();
    }
    
    
    private void fightInput() {//inputs while a combat is active
    	mov=combat.curMov(current,map);
    	tar=combat.curTarget(current);
    	
    	if(Gdx.input.isKeyJustPressed(Input.Keys.TAB)&&playerTurn) health= health ?false :true;
    	
        if (Gdx.input.justTouched()&&playerTurn) {
    		x=current.getSprite().getX();
    		y=current.getSprite().getY();
            touchPos.set(Gdx.input.getX(), Gdx.input.getY());
            viewport.unproject(touchPos);
            Pair p=new Pair((int)Math.floor(touchPos.x),(int)Math.floor(touchPos.y));
            boolean valid=false;
            
            if(combat.emptyTile(p)&&move) {//movement
                for(Pair i:mov) {
                	if(i.compareTo(p)==1) {
                		valid=true;
                		break;
                	}
                }
                if(valid) {
                	current.getSprite().setX((int)Math.floor(touchPos.x));
                	current.getSprite().setY((int)Math.floor(touchPos.y));
                	move=false;
                }
            }
            
            else if(act) {//action
                for(Pair i:tar) {
                	if(i.compareTo(p)==1) {
                		valid=true;
                		break;
                	}
                }
                if(valid) {
            		Char target=combat.getChar(p);
            		current.attack(target);
            		if(target.getHp()<=0) {
            			combat.removeChar(target);
            		}
            		act=false;
            		
                }
            	
            }

        }
        
        if(playerTurn&&Gdx.input.isKeyJustPressed(Input.Keys.ENTER)) {		//pass turn
        	if(combat.finished()) {
        		
            	for(Char c:playerDic.keySet()) {
            		Player p=(Player)c;
            		p.addLevel();
            	}
            	
        		endCombat();
            	
        	}else {
        		newTurn();
        	}
        }
    }
    
    private void newTurn() { //start a new combat turn
    	playerTurn=false;
    	act=true;
    	move=true;
    	current=combat.getFirst();
    	mov=combat.curMov(current,map);
    	
    	tar=combat.curTarget(current);
    	if(current instanceof Player) {
    		playerTurn=true;
    	}else {
    		combat.enmyTurn(current,map);	//handle enemy action and movement
        	if(combat.finished()) {
    			curMap=Integer.toString(Integer.parseInt(curMap)-1);
    			try {
    				map = new TmxMapLoader().load("space"+curMap+".tmx");
    			}catch(Exception e) {
    				curMap="0";
    				map = new TmxMapLoader().load("space"+curMap+".tmx");
    			}

        		endCombat();
            	
        	}else {
        		newTurn();
        	}
    	}
    	
    }
    
    private void endCombat() {	//action after the combat has ended
    	group.setY(4);
    	group.setX(1);
		fighting=false;
    	for(Char c:playerDic.keySet()) {
        	Player p=(Player)c;
        	p.restore();
        	p.getSprite().setX(playerDic.get(c).getX());
        	p.getSprite().setY(playerDic.get(c).getY());
    	}
        
    }

    @Override
    public void pause() {
        // Invoked when your application is paused.
    }

    @Override
    public void resume() {
        // Invoked when your application is resumed after pause.
    }

    @Override
    public void dispose() {	
    	green.dispose();
    	red.dispose();
    	yellow.dispose();
    	hpRed.dispose();
    	hpGreen.dispose();
    	buff.dispose();
    	debuff.dispose();
    	blue.dispose();
    	music.dispose();
    }
}
